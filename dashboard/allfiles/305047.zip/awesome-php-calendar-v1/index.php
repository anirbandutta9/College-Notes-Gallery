<?php
/**
The MIT License (MIT)
Copyright (c) 2014  www.thesoftwareguy.in

@author: Shahrukh Khan
@released date: 27th March 2014

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
error_reporting(E_ERROR | E_WARNING | E_PARSE);
date_default_timezone_set('Asia/Kolkata');
$siteURL = "http://localhost/awesome-php-calendar-v1/";

$currentYear = ((int)$_REQUEST["year"] != 0 )  ? ((int)$_REQUEST["year"]) : date("Y");
$currentMonth = ((int)$_REQUEST["month"] != 0 )  ? ((int)$_REQUEST["month"]) : date("n");
$currentMonth = str_pad($currentMonth, 2, "0", STR_PAD_LEFT);

if ($currentMonth == 1 ) {
  $previousMonth = 12;
  $previousYear = $currentYear -1;
} else if ($currentMonth == 12 ) {
  $nextYear = $currentYear + 1;
  $nextMonth = 1;
} else {
  $previousYear = $currentYear;
  $nextYear = $currentYear;

  $previousMonth = $currentMonth-1;
  $nextMonth = $currentMonth + 1;
}

// variables needed to setup calendar
$first_day = mktime(0,0,0,$currentMonth,1,$currentYear); 
$maxday_month = date("t",$first_day); 
$thismonth = getdate($first_day); 
$week_start_day = $thismonth['wday']; 
if (!$thismonth['wday']) $week_start_day = 7;
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="http://www.thesoftwareguy.in/favicon.ico" type="image/x-icon" />
    <meta name="author" content="Shahrukh Khan">
    <meta name="description" content="Awesome php calendar v1.0 - thesoftwareguy">
    <meta name="keywords" content="">
    <meta name="title" content="Awesome php calendar v1.0 - thesoftwareguy">

    <title>Awesome php calendar v1.0 - thesoftwareguy</title>

    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap/css/font-awesome.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="bootstrap/html5shiv.js"></script>
      <script src="bootstrap/respond.min.js"></script>
    <![endif]-->
  </head>
<body>

    <div class="navbar navbar-default navbar-static-top" role="navigation">
      <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="http://www.thesoftwareguy.in"><span class="glyphicon glyphicon-home"></span> thesoftwareguy</a>
        </div>


        <div class="collapse navbar-collapse pull-right" id="bs-example-navbar-collapse-1" >
          <ul class="nav navbar-nav">
            <li><a href="http://www.thesoftwareguy.in/mini-project/">More Free Projects</a></li>
            <li><a href="http://www.thesoftwareguy.in/awesome-php-calendar-v1-0/">Back to tutorial</a></li>
          </ul>

        </div>


      </div>

    </div>

    <div class="container mainbody">
      <div class="page-header">
        <h1>Awesome Php Calendar v1.0</h1>
      </div>
      <div class="clearfix"></div>

      <div class="container-fluid">

        <div class="calendar">
                    
          <div class="mainheader">
          <table style="width: 100%;">
            <tr>
              <td style="text-align: left;">
                <a href="<?php echo $siteURL; ?>index.php?month=<?php echo $currentMonth; ?>&year=<?php echo $currentYear-1; ?>" class="button prev_year" >prev year</a>
                <a href="<?php echo $siteURL; ?>index.php?month=<?php echo $previousMonth; ?>&year=<?php echo $previousYear; ?>" class="button prev_month" >prev month</a>        
              </td>
              <td style="text-align: center;"><h2><?php echo date("F Y",strtotime($currentYear ."-".$currentMonth."-01")); ?></h2></td>
              <td style="text-align: right;">
                <a href="<?php echo $siteURL; ?>index.php?month=<?php echo $nextMonth; ?>&year=<?php echo $nextYear; ?>" class="button next_month">next month</a>
                <a href="<?php echo $siteURL; ?>index.php?month=<?php echo $currentMonth; ?>&year=<?php echo $currentYear+1 ?>" class="button next_year">next year</a>
              </td>
            </tr>
          </table>
          </div>
          <div style="height:5px; clear:both; "></div>
          <div  class="maintable">
            <table>
            <tr>
              <td>Mon</td>
              <td>Tue</td>
              <td>Wed</td>
              <td>Thu</td>
              <td>Fri</td>
              <td>Sat</td>
              <td>Sun</td>
            </tr>
            <?php 
            for ($i=1; $i<($maxday_month+$week_start_day); $i++) { 
              
              if (($i % 7) == 1 ) echo "<tr>";
              if ($i < $week_start_day) { echo "<td>&nbsp;</td>"; continue; };
              
              
              $current_day = $i - $week_start_day + 1;
              $cday = str_pad($current_day, 2, "0", STR_PAD_LEFT);
              $currentDayCss = (date("Y-m-d") == $currentYear."-".$currentMonth."-".$cday) ? "selected" : "";
              
              echo "<td class='".$currentDayCss."'>". $current_day . "</td>";
	
              if (($i % 7) == 0 ) echo "</tr>";
            ?>
            
            <?php } 
            if (($i % 7) != 0 ) echo "</tr>";
            ?>
            </table>
          </div>
		  <div style="height:5px; clear:both; "></div>
          <table style="width: 100%;">
            <tr>
              <td align="left" >
                <?php 
                  $todaymonth=str_pad(date("m"), 2, "0", STR_PAD_LEFT);
                  $todayYear=date("Y");		  
                  ?>
                  <a href="<?php echo $siteURL; ?>index.php?month=<?php echo $todaymonth; ?>&year=<?php echo $todayYear; ?>" class="button">Back to today</a>
              </td>
              <td align="right">
                <b>Goto date:</b> &nbsp;
                <select name="month" id="month" class="selectbox">
				<?php 
				for($i=1; $i<=12; $i++) { 
                    $m=str_pad($i, 2, "0", STR_PAD_LEFT);
                    $sel = ($i == $currentMonth) ? " selected ": "";
					echo '<option value="'.$m.'" '.$sel.'>'.date("M", strtotime(date("Y-$i-01"))).'</option>';
				}
				?>
                 </select>
                <select name="year" id="year"  class="selectbox">
				<?php 
				for($i=1902; $i<2038; $i++) {
                    $sel = ($i == $currentYear ) ? " selected ": "";
					echo '<option value="'.$i.'" '.$sel.'>'.$i.'</option>';
				}
				?>
			   </select>
                <input type="button" value="show" class="button" onclick="gotoDate();" >
              </td>
            </tr>
          </table>
          
        </div>
      </div>
      <!-- Shameless Promotion starts -->
      <div style="clear: both; height: 10px;"></div>
      
      <div class="page-header">
        <h1>Follow Us</h1>
      </div>
      <div class="col-lg-12">
        <div class="col-lg-4">
          <iframe src="//www.facebook.com/plugins/likebox.php?href=http%3A%2F%2Fwww.facebook.com%2FThesoftwareguy7&amp;width&amp;height=290&amp;colorscheme=light&amp;show_faces=true&amp;header=true&amp;stream=false&amp;show_border=true&amp;appId=198210627014732" scrolling="no" frameborder="0" style="border:none; overflow:hidden; height:290px;" allowTransparency="true"></iframe>
        </div>
        <div class="col-lg-4">
          <div class="g-person" data-href="https://plus.google.com/116523474604785207782"  data-rel="author" data-layout="landscape"></div>
          <div style="clear: both; height: 15px;"></div>
          <div class="g-page" data-width="299" data-href="//plus.google.com/115374397759986535215" data-layout="landscape" data-rel="publisher"></div>
            <script type="text/javascript">
              (function() {
                var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                po.src = 'https://apis.google.com/js/platform.js';
                var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
              })();
            </script>
        </div>
        <div class="col-lg-4">
          <a href="https://twitter.com/thesoftwareguy7" class="twitter-follow-button" data-show-count="true" data-size="large">Follow @thesoftwareguy7</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>

        </div>
        
      </div>
      <!-- Shameless Promotion ends -->
    </div>
  <footer>
    <div class="navbar navbar-inverse footer">
      <div class="container-fluid">
        <div class="copyright">
          <a href="http://www.thesoftwareguy.in" target="_blank">&copy; thesoftwareguy  2013 - <?php echo date("Y"); ?> All rights reserved</a>
        </div>
      </div>
    </div>
  </footer>
  <script>
    function gotoDate() {
      var m = jQuery("#month").val();
      var y = jQuery("#year").val();
      window.location.href = "<?php echo $siteURL; ?>index.php?month="+m+"&year="+y;
    }
  </script>
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="bootstrap/js/jquery-1.9.0.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="bootstrap/js/bootstrap.min.js"></script>

</body>
</html>