To run this script simple extract the zip file in ur htdocs/www folder.
If you want to put the folder under some other folder then change this line 29 of index.php
$siteURL = "http://localhost/awesome-php-calendar-v1/";
to
$siteURL = "http://localhost/<tour foldername>/awesome-php-calendar-v1/";
