Build a CMS in an Afternoon with PHP and MySQL
http://www.elated.com/articles/cms-in-an-afternoon-php-mysql/

All code copyright Elated Communications Ltd 2011.
http://www.elated.com/

